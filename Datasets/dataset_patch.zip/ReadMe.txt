로컬이건 코랩이건 다 가능합니다.

1. 원본 모델로 최초 1회 실행이 필요합니다. {이게 최선이었습니다}
2. dataset.py 파일 기존의 것과 교체해주세요
3. ./data/ml-100k/raw 의 경로로 가셔서 해당 폴더 u.data, u.info, u1.test 을 넣어주시기만 하면 됩니다.

It doesn't matter whether you are on local or colab, etc

1. You need to run with original [default model].
2. Replace the dataset.py in original, with the dataset.py in my file.
3. Go to ./data/ml-100k/raw and paste u.data, u.info, u1.test.

변경된 dataset.py 는 다운로드 기능이 없습니다.
최초 원본 모델 실행은 경로 편의상 꼭 필요합니다.

Adjusted dataset.py doesn't have download functions.
The initial run with original model is mendatory. 